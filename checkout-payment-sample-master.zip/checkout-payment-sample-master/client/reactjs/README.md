# Checkout Pro with ReactJS example

## Development

Install dependencies and start a local web server by running:

```
npm install
npm run start
```

Open http://localhost:3000 to view it in the browser
