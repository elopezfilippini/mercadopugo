# Checkout Pro with HTML/JS example

Open http://localhost:8080 to view it in the browser.
